% ==============================================================================
% 
%           Group-based Sparse Representation for Image Restoration
%                          
% 
%                         Version 3.0, 15-July-2015
% 
%                       Copyright (C) 2015  Jian Zhang
% 
% ==============================================================================
% 
% OVERVIEW:
% 
%   These MATLAB programs implement the image restoration algorithms via 
%   group-based sparse representation (GSR) modeling as described in paper:
%   
%     Title:  Group-based Sparse Representation for Image Restoration
%     Author: Jian Zhang, Debin Zhao, Wen Gao 
%     State: IEEE Transactions on Image Processing
%     
% 
%   Specifically, this packages contains  the implementions for three
%   applications: image inpainting, image deblurring and image compressive
%   sensing recovery, which can be found in each directory. 
%
%   
%   This code relies on 
%   Wavelet Software package(http://eeweb.poly.edu/iselesni/WaveletSoftware/)
%   Pascal Getreuer's Wavelet CDF 9/7 package (http://www.getreuer.info/home/waveletcdf97)
%   FSIM-Feature Similarity Index (http://www4.comp.polyu.edu.hk/~cslzhang/IQA/FSIM/FSIM.htm)
%   MH-BCS-SPL package(http://www.ece.msstate.edu/~fowler/BCSSPL/)
%   All will need to reside within the current MATLAB search path.
% 
%
% 
% ==============================================================================
% 
% 
% AVAILABILITY:
% 
%   For updated versions of GSR,consult: http://idm.pku.edu.cn/staff/zhangjian/GSR/
% 
% 
% ==============================================================================
% 
% 
% COPYRIGHT AND LICENSE INFORMATION:
% 
%   Copyright (C) 2015 Jian Zhang
%   
%   The programs herein are free software; you can redistribute
%   them and/or modify them under the terms of the GNU General Public License
%   as published by the Free Software Foundation; either version 2
%   of the License, or (at your option) any later version.
% 
%   All programs herein are distributed in the hope that
%   they will be useful, but WITHOUT ANY WARRANTY; without even the implied
%   warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
%   the full text of the appropriate license for more details.
%   
% 
% ==============================================================================
